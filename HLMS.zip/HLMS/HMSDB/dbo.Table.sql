﻿CREATE TABLE [dbo].[Doctbl] (
    [Docid]    INT          NOT NULL,
    [DocName]  VARCHAR (50) NOT NULL,
    [DocExp] INT          NOT NULL,
    [Password] INT NOT NULL, 
    PRIMARY KEY CLUSTERED ([Docid] ASC)
);

